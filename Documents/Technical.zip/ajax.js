function getRequestObject() {
	if (window.ActiveXObject) {
		return(new ActiveXObject("Microsoft.XMLHTTP"));
	} else if (window.XMLHttpRequest) {
		return(new XMLHttpRequest());
	} else {
		return(null);
	}
}

function sendRequestWithData(address, data, responseHandler, request) {
	//request = getRequestObject();
	request.onreadystatechange = responseHandler;
	request.open("POST", address, true);
	request.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	request.send(data);
}
function sendRequestWithDataNon(address, data, request) {
	//request = getRequestObject();
	//request.onreadystatechange = responseHandler;
	request.open("POST", address, false);
	request.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	request.send(data);
	
}
function sendRequest(address, responseHandler, request) {
	//request = getRequestObject();
	request.onreadystatechange = responseHandler;
	request.open("POST", address, true);
	request.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	request.send(1);//For firefox
}

function getXmlDoc(doc) {
	var xmlDocument;
	if (window.ActiveXObject) {
		xmlDocument=new ActiveXObject("Microsoft.XMLDOM");
		xmlDocument.async=false;
		xmlDocument.loadXML(doc);
	}
	// code for Mozilla, Firefox, Opera, etc.
	else if (document.implementation && document.implementation.createDocument) {
		var parser=new DOMParser();
		xmlDocument=parser.parseFromString(doc, "text/xml");
	}
	return(xmlDocument);
}
function sendRequestPostNoFunction(address, parameters, sendRequest) {
	sendRequest.open("POST", address, true);
	sendRequest.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	if(parameters != null) {
		sendRequest.send(parameters);
	}else {
		sendRequest.send(null);
	}
}